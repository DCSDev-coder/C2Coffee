import type { FastifyInstance } from "fastify";
import type { RowDataPacket } from "mysql2/promise";
import { z } from "zod";
import { authenticateRequest } from "../../auth/guard.js";
import { env } from "../../config/env.js";
import { mysqlPool } from "../../db/mysql.js";
import { ApiError } from "../errors.js";
import { getBootstrapForUser } from "./auth.js";
import { getUserResponse } from "./me.js";
import {
  getMobileOrderingStatus,
  isStoreAcceptingMobileOrdersNow,
  isStoreOpenNow,
  normalizeWeeklyHours,
} from "../../services/store-availability.js";

const menuQuerySchema = z.object({
  store_id: z.coerce.number().int().positive(),
});

type StoreRow = RowDataPacket & {
  id: number;
  code: string;
  name: string;
  status: "active" | "inactive";
  supports_pickup: number;
  pickup_lead_minutes: number;
  address_line_1: string | null;
  address_line_2: string | null;
  city: string | null;
  state: string | null;
  postcode: string | null;
  latitude: string | number | null;
  longitude: string | number | null;
  timezone: string;
  temporarily_closed: number;
  weekly_hours_json: unknown;
};

type MenuRow = RowDataPacket & {
  category_id: number;
  category_code: string;
  category_name: string;
  category_product_kind_code: string;
  category_sort_order: number;
  subcategory_id: number | null;
  subcategory_code: string | null;
  subcategory_name: string | null;
  item_id: number;
  item_code: string;
  item_name: string;
  item_description: string | null;
  base_price_rm: string;
  base_price_token: number;
  base_calories_kcal: number;
  image_url: string | null;
  is_available: number;
  is_handcrafted_drink: number;
  is_qualifying_cup: number;
  allow_choice_of_beans: number;
  allow_espresso_shot: number;
  allow_choice_of_milk: number;
  allow_choice_of_sweetness: number;
  allow_ice_level: number;
  allow_temperature: number;
  allow_sparkling_mixer: number;
  allow_order_type: number;
  allow_remarks: number;
  tier_code: "kawan" | "dilamun" | "ketagih" | "legend" | null;
  token_price: number | null;
  modifier_group_id: number | null;
  modifier_group_code: string | null;
  modifier_group_name: string | null;
  modifier_selection_type: "single" | "multi" | null;
  modifier_min_select: number | null;
  modifier_max_select: number | null;
  modifier_is_required: number | null;
  modifier_group_sort_order: number | null;
  modifier_option_id: number | null;
  modifier_option_code: string | null;
  modifier_option_name: string | null;
  modifier_option_price_delta_rm: string | null;
  modifier_option_token_price_delta: number | null;
  modifier_option_sort_order: number | null;
};

type MenuModifierOption = {
  id: number;
  code: string;
  name: string;
  price_delta_rm: string;
  token_price_delta: number;
  calorie_delta_kcal: number;
  image_url: string | null;
  color_hex: string | null;
  gradient_end_hex: string | null;
  gradient_direction: string | null;
  is_default: boolean;
};

type MenuModifierGroup = {
  id: number;
  code: string;
  name: string;
  selection_type: "single" | "multi";
  min_select: number;
  max_select: number;
  is_required: boolean;
  source: "item" | "library";
  hidden_when_option_ids: number[];
  options: Array<MenuModifierOption>;
};

type MenuItemResponse = {
  id: number;
  code: string;
  name: string;
  description: string | null;
  base_price_rm: string;
  base_price_token: number;
  base_calories_kcal: number;
  image_url: string | null;
  is_available: boolean;
  is_handcrafted_drink: boolean;
  is_qualifying_cup: boolean;
  allow_choice_of_beans: boolean;
  allow_espresso_shot: boolean;
  allow_choice_of_milk: boolean;
  allow_choice_of_sweetness: boolean;
  allow_ice_level: boolean;
  allow_temperature: boolean;
  allow_sparkling_mixer: boolean;
  allow_order_type: boolean;
  allow_remarks: boolean;
  subcategory_id: number | null;
  subcategory_code: string | null;
  subcategory_name: string | null;
  product_kind_code: string;
  product_kind_name: string;
  token_prices: Record<string, number>;
  modifier_groups: Array<MenuModifierGroup>;
};

type LibraryModifierRow = RowDataPacket & {
  group_id: number;
  group_name: string;
  selection_type: "single" | "multi";
  min_select: number;
  max_select: number;
  is_required: number;
  applies_to: "all_drinks" | "selected_items";
  menu_item_id: number | null;
  option_id: number;
  option_name: string;
  option_image_url: string | null;
  option_color_hex: string | null;
  option_gradient_end_hex: string | null;
  option_gradient_direction: string | null;
  option_price_delta_rm: string;
  option_token_price_delta: number;
  option_calorie_delta_kcal: number;
  option_is_default: number;
};

type MenuCategoryResponse = {
  id: number;
  code: string;
  name: string;
  sort_order: number;
  product_kind_code: string;
  product_kind_name: string;
  items: Array<MenuItemResponse>;
};

function resolveProductKind(
  productKindCode: string | null | undefined,
  categoryCode?: string,
): { code: string; name: string } {
  switch (
    String(productKindCode ?? "")
      .trim()
      .toLowerCase()
  ) {
    case "drink":
      return { code: "drink", name: "Drinks" };
    case "food":
      return { code: "food", name: "Food" };
    case "merchandise":
      return { code: "merchandise", name: "Merchandise" };
    case "candle":
      return { code: "candle", name: "Candles" };
    case "other":
      return { code: "other", name: "Other" };
    default:
      switch (
        String(categoryCode ?? "")
          .trim()
          .toLowerCase()
      ) {
        case "coffee":
        case "non_coffee":
          return { code: "drink", name: "Drinks" };
        case "food":
          return { code: "food", name: "Food" };
        case "merchandise":
          return { code: "merchandise", name: "Merchandise" };
        case "candles":
          return { code: "candle", name: "Candles" };
        default:
          return { code: "other", name: "Other" };
      }
  }
}

type HomeBannerRow = RowDataPacket & {
  id: number;
  code: string;
  title: string;
  subtitle: string;
  image_source: string;
  media_type: "image" | "gif";
  animation_duration_ms: number;
  banner_type: "voucher" | "event" | "new_item" | "general" | "partner";
  partner_name: string | null;
  sponsored_label: number;
  cta_label: string | null;
  action_type: "none" | "external_url" | "email";
  action_value: string | null;
  destination_type: "reward_section" | "menu" | "calendar";
  secondary_destination_type: "reward_section" | "menu" | "calendar" | null;
  target_value: string | null;
  starts_at: Date | string | null;
  ends_at: Date | string | null;
  placement: "home" | "profile" | "both";
  sort_order: number;
  home_sort_order: number;
  floating_sort_order: number;
  partnership_sort_order: number;
  floating_priority: number;
  created_at: Date | string;
  is_active: number;
};

type CustomerAppearanceRow = RowDataPacket & {
  primary_color: string | null;
  secondary_color: string | null;
  text_color: string | null;
  background_color: string | null;
  muted_text_color: string | null;
};

async function getCustomerAppearance(
  userId: number,
  tierCode: string,
): Promise<CustomerAppearanceRow> {
  const [rows] = await mysqlPool.query<CustomerAppearanceRow[]>(
    `SELECT
       COALESCE(appearance.primary_color, t.primary_color) AS primary_color,
       COALESCE(appearance.secondary_color, t.secondary_color) AS secondary_color,
       COALESCE(appearance.text_color, t.text_color) AS text_color,
       COALESCE(appearance.background_color, t.background_color) AS background_color,
       COALESCE(appearance.muted_text_color, t.muted_text_color) AS muted_text_color
     FROM customer_tenant_memberships ctm
     INNER JOIN admin_tenants t ON t.id = ctm.tenant_id
     LEFT JOIN loyalty_tiers lt ON lt.code = :tierCode AND lt.is_active = 1
     LEFT JOIN tenant_loyalty_tier_appearances appearance
       ON appearance.tenant_id = ctm.tenant_id AND appearance.loyalty_tier_id = lt.id
     WHERE ctm.user_id = :userId AND t.status = 'active'
     ORDER BY ctm.tenant_id ASC
     LIMIT 1`,
    { userId, tierCode },
  );
  return (
    rows[0] ?? {
      primary_color: "#2E5E58",
      secondary_color: "#D4AF7A",
      text_color: "#2C2C2C",
      background_color: "#FFFFFF",
      muted_text_color: "#6B7280",
    }
  );
}

let homeBannerColumnsPromise: Promise<Set<string>> | null = null;

async function getHomeBannerColumns(): Promise<Set<string>> {
  if (!homeBannerColumnsPromise) {
    homeBannerColumnsPromise = mysqlPool
      .query<Array<RowDataPacket>>("SHOW COLUMNS FROM home_banners")
      .then(
        ([rows]) =>
          new Set(
            rows
              .map((row) =>
                String((row as { Field?: string }).Field ?? "").trim(),
              )
              .filter(Boolean),
          ),
      );
  }

  return homeBannerColumnsPromise;
}

function supportsHomeBannerTargeting(columns: Set<string>): boolean {
  return [
    "banner_type",
    "destination_type",
    "secondary_destination_type",
    "target_value",
    "starts_at",
    "ends_at",
  ].every((column) => columns.has(column));
}

function buildHomeBannerSelectClause(columns: Set<string>): string {
  const selects = [
    "hb.id",
    "hb.code",
    "hb.title",
    "hb.subtitle",
    "hb.image_source",
    columns.has("media_type") ? "hb.media_type" : "'image' AS media_type",
    columns.has("animation_duration_ms")
      ? "hb.animation_duration_ms"
      : "0 AS animation_duration_ms",
  ];

  if (supportsHomeBannerTargeting(columns)) {
    selects.push(
      "hb.banner_type",
      "hb.destination_type",
      "hb.secondary_destination_type",
      "hb.target_value",
      "hb.starts_at",
      "hb.ends_at",
    );
  } else {
    selects.push(
      "'general' AS banner_type",
      "'menu' AS destination_type",
      "NULL AS secondary_destination_type",
      "NULL AS target_value",
      "NULL AS starts_at",
      "NULL AS ends_at",
    );
  }

  if (
    [
      "partner_name",
      "sponsored_label",
      "cta_label",
      "action_type",
      "action_value",
    ].every((column) => columns.has(column))
  ) {
    selects.push(
      "hb.partner_name",
      "hb.sponsored_label",
      "hb.cta_label",
      "hb.action_type",
      "hb.action_value",
    );
  } else {
    selects.push(
      "NULL AS partner_name",
      "1 AS sponsored_label",
      "NULL AS cta_label",
      "'none' AS action_type",
      "NULL AS action_value",
    );
  }

  selects.push(
    "hb.placement",
    "hb.sort_order",
    columns.has("home_sort_order")
      ? "hb.home_sort_order"
      : "hb.sort_order AS home_sort_order",
    columns.has("floating_sort_order")
      ? "hb.floating_sort_order"
      : "hb.sort_order AS floating_sort_order",
    columns.has("partnership_sort_order")
      ? "hb.partnership_sort_order"
      : "hb.sort_order AS partnership_sort_order",
    columns.has("floating_priority")
      ? "hb.floating_priority"
      : "0 AS floating_priority",
    "hb.is_active",
    "hb.created_at",
  );

  return selects.join(",\n          ");
}

export async function registerCatalogRoutes(
  app: FastifyInstance,
): Promise<void> {
  app.get("/v1/public/menu", async (_request, reply) => {
    const [storeRows] = await mysqlPool.query<
      Array<RowDataPacket & { id: number; name: string }>
    >(
      `
        SELECT s.id, s.name
        FROM stores s
        JOIN admin_tenants t ON t.id = s.tenant_id
        WHERE t.code = :tenantCode
          AND t.status = 'active'
          AND s.status = 'active'
          AND s.is_customer_facing = 1
        ORDER BY s.id ASC
        LIMIT 1
      `,
      { tenantCode: env.DEPLOYMENT_TENANT_CODE },
    );

    const store = storeRows[0];
    if (!store) {
      throw new ApiError(404, "public_store_not_found", "No public store is configured.");
    }

    const catalog = await loadCatalogMenu(store.id);
    const drinks = catalog.categories.flatMap((category) =>
      category.items
        .filter((item) => item.product_kind_code === "drink")
        .map((item) => ({
          id: item.id,
          code: item.code,
          category: category.name,
          name: item.name,
          description: item.description,
          image_url: item.image_url,
        })),
    );

    reply.header("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
    return {
      store_id: store.id,
      store_name: store.name,
      drinks,
    };
  });

  app.get("/v1/public/tiers", async (_request, reply) => {
    const [rows] = await mysqlPool.query<Array<RowDataPacket & {
      id: number;
      code: string;
      name: string;
      min_cups: number | string;
      promotion_text: string;
      reward_config_json: unknown;
    }>>(
      `
        SELECT
          t.id AS tenant_id,
          lt.id,
          lt.code,
          lt.name,
          lt.min_cups,
          lt.promotion_text,
          lt.reward_config_json
        FROM loyalty_tiers lt
        JOIN admin_tenants t
          ON t.code = :tenantCode
         AND t.status = 'active'
        WHERE lt.is_active = 1
        ORDER BY lt.min_cups ASC, lt.sort_order ASC, lt.id ASC
      `,
      { tenantCode: env.DEPLOYMENT_TENANT_CODE },
    );

    const rewardIds = [...new Set(rows.flatMap((row) => {
      let config: unknown = row.reward_config_json;
      if (typeof config === "string") {
        try {
          config = JSON.parse(config);
        } catch {
          config = null;
        }
      }

      if (!config || typeof config !== "object") return [];
      const raw = config as {
        voucherTemplateIds?: unknown;
        birthdayVoucherTemplateIds?: unknown;
      };
      return [
        ...(Array.isArray(raw.voucherTemplateIds) ? raw.voucherTemplateIds : []),
        ...(Array.isArray(raw.birthdayVoucherTemplateIds) ? raw.birthdayVoucherTemplateIds : []),
      ]
        .map((value) => Number(value))
        .filter((value) => Number.isInteger(value) && value > 0);
    }))];

    const rewardNames = new Map<number, string>();
    if (rewardIds.length > 0) {
      const bindings: Record<string, number> = { tenantId: Number((rows[0] as { tenant_id?: number }).tenant_id ?? 0) };
      const placeholders = rewardIds.map((id, index) => {
        const key = `rewardId${index}`;
        bindings[key] = id;
        return `:${key}`;
      });
      const [rewardRows] = await mysqlPool.query<Array<RowDataPacket & { id: number; name: string }>>(
        `
          SELECT id, name
          FROM voucher_templates
          WHERE tenant_id = :tenantId
            AND is_active = 1
            AND id IN (${placeholders.join(", ")})
        `,
        bindings,
      );
      rewardRows.forEach((reward) => rewardNames.set(Number(reward.id), String(reward.name ?? "").trim()));
    }

    reply.header("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
    return {
      tiers: rows.map((row) => ({
        id: Number(row.id),
        code: String(row.code ?? "").trim().toLowerCase(),
        name: String(row.name ?? "").trim(),
        min_cups: Number(row.min_cups ?? 0),
        promotion_text: String(row.promotion_text ?? "").trim(),
        rewards: (() => {
          let config: unknown = row.reward_config_json;
          if (typeof config === "string") {
            try {
              config = JSON.parse(config);
            } catch {
              config = null;
            }
          }
          if (!config || typeof config !== "object") return [];
          const raw = config as { voucherTemplateIds?: unknown; birthdayVoucherTemplateIds?: unknown };
          return [
            ...(Array.isArray(raw.voucherTemplateIds) ? raw.voucherTemplateIds : []),
            ...(Array.isArray(raw.birthdayVoucherTemplateIds) ? raw.birthdayVoucherTemplateIds : []),
          ]
            .map((value) => rewardNames.get(Number(value)))
            .filter((value): value is string => Boolean(value));
        })(),
      })),
    };
  });

  app.get(
    "/v1/bootstrap",
    { preHandler: authenticateRequest },
    async (request) => {
      const [user, summary] = await Promise.all([
        getUserResponse(request.auth.userId),
        getBootstrapForUser(request.auth.userId),
      ]);
      const appearance = await getCustomerAppearance(
        request.auth.userId,
        summary.tier,
      );

      return {
        user,
        token: {
          balance_available: summary.token_balance,
          balance_reserved: summary.token_reserved,
          balance_cap: summary.token_cap,
          has_completed_topup: summary.has_completed_topup,
          can_place_order: true,
        },
        loyalty: {
          tier: summary.tier,
          cups_last_180d: summary.cups_last_180d,
          next_tier: null,
          tiers: summary.tiers,
        },
        active_order: null,
        appearance,
        home_banners: await listActiveHomeBanners(request.auth.userId),
      };
    },
  );

  app.get(
    "/v1/loyalty/tiers",
    { preHandler: authenticateRequest },
    async (request) => {
      const summary = await getBootstrapForUser(request.auth.userId);
      return {
        tier: summary.tier,
        cups_last_180d: summary.cups_last_180d,
        tiers: summary.tiers,
      };
    },
  );

  app.get(
    "/v1/stores",
    { preHandler: authenticateRequest },
    async (request) => {
      return {
        stores: await listActiveStores(request.auth.userId),
      };
    },
  );

  app.get("/v1/menu", { preHandler: authenticateRequest }, async (request) => {
    const { store_id: storeId } = menuQuerySchema.parse(request.query);

    const stores = await listActiveStores(request.auth.userId);
    if (!stores.some((store) => store.id === storeId)) {
      throw new ApiError(404, "store_not_found", "Store was not found.");
    }

    return loadCatalogMenu(storeId);
  });

  app.post(
    "/v1/marketing/banners/:code/engagement",
    { preHandler: authenticateRequest },
    async (request) => {
      const code = z
        .string()
        .trim()
        .min(1)
        .max(80)
        .parse((request.params as { code: string }).code);
      const { event_type: eventType } = z
        .object({
          event_type: z.enum(["impression", "click"]),
        })
        .parse(request.body);

      const [result] = await mysqlPool.execute(
        `INSERT INTO home_banner_engagements (tenant_id, banner_id, user_id, event_type, occurred_at)
       SELECT hb.tenant_id, hb.id, :userId, :eventType, UTC_TIMESTAMP()
       FROM home_banners hb
       JOIN customer_tenant_memberships ctm
         ON ctm.tenant_id = hb.tenant_id AND ctm.user_id = :userId
       WHERE hb.code = :code AND hb.banner_type = 'partner' AND hb.is_active = 1
         AND (hb.starts_at IS NULL OR hb.starts_at <= UTC_TIMESTAMP())
         AND (hb.ends_at IS NULL OR hb.ends_at > UTC_TIMESTAMP())
         AND NOT EXISTS (
           SELECT 1
           FROM home_banner_engagements recent
           WHERE recent.banner_id = hb.id
             AND recent.user_id = :userId
             AND recent.event_type = :eventType
             AND recent.occurred_at >= UTC_TIMESTAMP() - INTERVAL 10 MINUTE
         )
       LIMIT 1`,
        { userId: request.auth.userId, eventType, code },
      );
      return {
        recorded:
          Number((result as { affectedRows?: number })?.affectedRows ?? 0) ===
          1,
      };
    },
  );
}

export async function loadCatalogMenu(storeId: number) {
  const [rows] = await mysqlPool.query<Array<MenuRow>>(
    `
        SELECT
          c.id AS category_id,
          c.code AS category_code,
          c.name AS category_name,
          COALESCE(NULLIF(LOWER(c.product_kind_code), ''), CASE
            WHEN LOWER(c.code) IN ('coffee', 'non_coffee') THEN 'drink'
            WHEN LOWER(c.code) = 'food' THEN 'food'
            WHEN LOWER(c.code) = 'merchandise' THEN 'merchandise'
            WHEN LOWER(c.code) = 'candles' THEN 'candle'
            ELSE 'other'
          END) AS category_product_kind_code,
          c.sort_order AS category_sort_order,
          sc.id AS subcategory_id,
          sc.code AS subcategory_code,
          sc.name AS subcategory_name,
          i.id AS item_id,
          i.code AS item_code,
          i.name AS item_name,
          i.description AS item_description,
          CAST(i.base_price_rm AS CHAR) AS base_price_rm,
          i.base_price_token,
          CAST(COALESCE(recipe.calculated_base_calories_kcal, i.base_calories_kcal) AS UNSIGNED) AS base_calories_kcal,
          i.image_url,
          COALESCE(a.is_available, 1) AS is_available,
          i.is_handcrafted_drink,
          i.is_qualifying_cup,
          i.allow_choice_of_beans,
          i.allow_espresso_shot,
          i.allow_choice_of_milk,
          i.allow_choice_of_sweetness,
          i.allow_ice_level,
          i.allow_temperature,
          i.allow_sparkling_mixer,
          i.allow_order_type,
          i.allow_remarks,
          tp.tier_code,
          tp.token_price,
          img.id AS modifier_group_id,
          img.code AS modifier_group_code,
          img.name AS modifier_group_name,
          img.selection_type AS modifier_selection_type,
          img.min_select AS modifier_min_select,
          img.max_select AS modifier_max_select,
          img.is_required AS modifier_is_required,
          img.sort_order AS modifier_group_sort_order,
          imo.id AS modifier_option_id,
          imo.code AS modifier_option_code,
          imo.name AS modifier_option_name,
          CAST(imo.price_delta_rm AS CHAR) AS modifier_option_price_delta_rm,
          imo.token_price_delta AS modifier_option_token_price_delta,
          imo.sort_order AS modifier_option_sort_order
        FROM menu_categories c
        JOIN menu_items i
          ON i.category_id = c.id
         AND i.is_active = 1
        LEFT JOIN menu_subcategories sc
          ON sc.id = i.subcategory_id
        LEFT JOIN menu_item_store_availability a
          ON a.store_id = :storeId
         AND a.menu_item_id = i.id
        LEFT JOIN (
          SELECT r.menu_item_id, ROUND(SUM(c.quantity * ingredient.calories_per_100_units / 100)) AS calculated_base_calories_kcal
          FROM menu_item_recipe_versions r
          JOIN menu_item_recipe_components c ON c.recipe_version_id = r.id
          JOIN nutrition_ingredients ingredient ON ingredient.id = c.ingredient_id
          WHERE r.status = 'active'
          GROUP BY r.menu_item_id
        ) recipe ON recipe.menu_item_id = i.id
        LEFT JOIN menu_item_token_prices tp
          ON tp.menu_item_id = i.id
         AND tp.is_enabled = 1
         AND tp.effective_from <= UTC_TIMESTAMP()
         AND (tp.effective_to IS NULL OR tp.effective_to > UTC_TIMESTAMP())
        LEFT JOIN item_modifier_groups img
          ON img.menu_item_id = i.id
        LEFT JOIN item_modifier_options imo
          ON imo.modifier_group_id = img.id
         AND imo.is_active = 1
        WHERE c.is_active = 1
        ORDER BY
          c.sort_order,
          c.id,
          i.name ASC,
          i.id,
          tp.tier_code,
          img.sort_order,
          img.id,
          imo.sort_order,
          imo.id
      `,
    { storeId },
  );

  const categories = new Map<number, MenuCategoryResponse>();

  const itemsByCategory = new Map<string, number>();

  for (const row of rows) {
    const category =
      categories.get(row.category_id) ??
      (() => {
        const productKind = resolveProductKind(
          row.category_product_kind_code,
          row.category_code,
        );
        return {
          id: row.category_id,
          code: row.category_code,
          name: row.category_name,
          sort_order: row.category_sort_order,
          product_kind_code: productKind.code,
          product_kind_name: productKind.name,
          items: [],
        } satisfies MenuCategoryResponse;
      })();

    if (!categories.has(row.category_id)) {
      categories.set(row.category_id, category);
    }

    const itemKey = `${row.category_id}:${row.item_id}`;
    let itemIndex = itemsByCategory.get(itemKey);
    if (itemIndex === undefined) {
      const productKind = resolveProductKind(
        row.category_product_kind_code,
        row.category_code,
      );
      category.items.push({
        id: row.item_id,
        code: row.item_code,
        name: row.item_name,
        description: row.item_description,
        base_price_rm: row.base_price_rm,
        base_price_token: row.base_price_token,
        base_calories_kcal: row.base_calories_kcal,
        image_url: _resolveImageUrl(row.image_url),
        is_available: row.is_available === 1,
        is_handcrafted_drink: row.is_handcrafted_drink === 1,
        is_qualifying_cup: row.is_qualifying_cup === 1,
        allow_choice_of_beans: row.allow_choice_of_beans === 1,
        allow_espresso_shot: row.allow_espresso_shot === 1,
        allow_choice_of_milk: row.allow_choice_of_milk === 1,
        allow_choice_of_sweetness: row.allow_choice_of_sweetness === 1,
        allow_ice_level: row.allow_ice_level === 1,
        allow_temperature: row.allow_temperature === 1,
        allow_sparkling_mixer: row.allow_sparkling_mixer === 1,
        allow_order_type: row.allow_order_type === 1,
        allow_remarks: row.allow_remarks === 1,
        subcategory_id: row.subcategory_id,
        subcategory_code: row.subcategory_code,
        subcategory_name: row.subcategory_name,
        product_kind_code: productKind.code,
        product_kind_name: productKind.name,
        token_prices: {},
        modifier_groups: [],
      });
      itemIndex = category.items.length - 1;
      itemsByCategory.set(itemKey, itemIndex);
    }

    const item = category.items[itemIndex];

    if (row.tier_code && row.token_price !== null) {
      item.token_prices[row.tier_code] = row.token_price;
    }

    if (row.modifier_group_id !== null) {
      let modifierGroup = item.modifier_groups.find(
        (group) => group.id === row.modifier_group_id,
      );

      if (!modifierGroup) {
        modifierGroup = {
          id: row.modifier_group_id,
          code: row.modifier_group_code ?? "",
          name: row.modifier_group_name ?? "",
          selection_type: row.modifier_selection_type ?? "single",
          min_select: row.modifier_min_select ?? 0,
          max_select: row.modifier_max_select ?? 1,
          is_required: row.modifier_is_required === 1,
          source: "item",
          hidden_when_option_ids: [],
          options: [],
        };
        item.modifier_groups.push(modifierGroup);
      }

      if (row.modifier_option_id !== null) {
        const alreadyExists = modifierGroup.options.some(
          (option) => option.id === row.modifier_option_id,
        );
        if (!alreadyExists) {
          modifierGroup.options.push({
            id: row.modifier_option_id,
            code: row.modifier_option_code ?? "",
            name: row.modifier_option_name ?? "",
            price_delta_rm: row.modifier_option_price_delta_rm ?? "0.00",
            token_price_delta: row.modifier_option_token_price_delta ?? 0,
            calorie_delta_kcal: 0,
            image_url: null,
            color_hex: null,
            gradient_end_hex: null,
            gradient_direction: "diagonal",
            is_default: false,
          });
        }
      }
    }
  }

  const itemsById = new Map<number, MenuItemResponse>();
  for (const category of categories.values()) {
    for (const item of category.items) itemsById.set(item.id, item);
  }
  const [libraryRows] = await mysqlPool.query<Array<LibraryModifierRow>>(
    `SELECT g.id AS group_id, g.name AS group_name, g.selection_type, g.min_select, g.max_select, g.is_required, g.applies_to,
              a.menu_item_id, o.id AS option_id, o.name AS option_name, o.image_url AS option_image_url, o.color_hex AS option_color_hex, o.gradient_end_hex AS option_gradient_end_hex, o.gradient_direction AS option_gradient_direction,
              CAST(o.price_delta_rm AS CHAR) AS option_price_delta_rm, o.token_price_delta AS option_token_price_delta,
              o.calorie_delta_kcal AS option_calorie_delta_kcal,
              o.is_default AS option_is_default
       FROM stores s
       JOIN menu_option_groups g ON g.tenant_id = s.tenant_id AND g.is_active = 1
       JOIN menu_option_group_options o ON o.option_group_id = g.id AND o.is_active = 1
       LEFT JOIN menu_option_group_items a ON a.option_group_id = g.id
       WHERE s.id = :storeId
       ORDER BY g.sort_order, g.id, o.sort_order, o.id`,
    { storeId },
  );
  const [optionNutritionRows] = await mysqlPool.query<Array<RowDataPacket>>(
    `SELECT n.menu_item_id, n.option_group_option_id, n.calorie_delta_kcal
       FROM menu_item_option_nutrition_overrides n
       JOIN menu_items i ON i.id = n.menu_item_id
       JOIN menu_categories c ON c.id = i.category_id
       WHERE LOWER(COALESCE(c.product_kind_code, '')) = 'drink'`,
    {},
  );
  const optionCaloriesByItem = new Map<string, number>();
  for (const row of optionNutritionRows)
    optionCaloriesByItem.set(
      `${row.menu_item_id}:${row.option_group_option_id}`,
      Number(row.calorie_delta_kcal),
    );
  const [exclusionRows] = await mysqlPool.query<Array<RowDataPacket>>(
    `SELECT e.menu_item_id, e.option_group_option_id
       FROM menu_item_option_exclusions e
       JOIN menu_items i ON i.id = e.menu_item_id AND i.is_active = 1
       WHERE EXISTS (
         SELECT 1 FROM menu_option_group_options o
         JOIN menu_option_groups g ON g.id = o.option_group_id
         JOIN stores s ON s.tenant_id = g.tenant_id AND s.id = :storeId
         WHERE o.id = e.option_group_option_id
       )`,
    { storeId },
  );
  const [visibilityRows] = await mysqlPool.query<Array<RowDataPacket>>(
    `SELECT r.option_group_id, r.trigger_option_id
       FROM menu_option_group_visibility_rules r
       JOIN menu_option_groups g ON g.id = r.option_group_id
       JOIN stores s ON s.tenant_id = g.tenant_id
       WHERE s.id = :storeId`,
    { storeId },
  );
  const hiddenWhenByGroup = new Map<number, number[]>();
  for (const row of visibilityRows) {
    const groupId = Number(row.option_group_id);
    hiddenWhenByGroup.set(groupId, [
      ...(hiddenWhenByGroup.get(groupId) ?? []),
      Number(row.trigger_option_id),
    ]);
  }
  const excludedOptionIdsByItem = new Map<number, Set<number>>();
  for (const row of exclusionRows) {
    const excludedIds =
      excludedOptionIdsByItem.get(Number(row.menu_item_id)) ??
      new Set<number>();
    excludedIds.add(Number(row.option_group_option_id));
    excludedOptionIdsByItem.set(Number(row.menu_item_id), excludedIds);
  }
  for (const row of libraryRows) {
    const targets =
      row.applies_to === "all_drinks"
        ? [...itemsById.values()].filter(
            (item) => item.product_kind_code === "drink",
          )
        : row.menu_item_id
          ? ([itemsById.get(row.menu_item_id)].filter(
              Boolean,
            ) as MenuItemResponse[])
          : [];
    for (const item of targets) {
      if (excludedOptionIdsByItem.get(item.id)?.has(Number(row.option_id)))
        continue;
      let group = item.modifier_groups.find(
        (candidate) =>
          candidate.source === "library" && candidate.id === row.group_id,
      );
      if (!group) {
        group = {
          id: row.group_id,
          code: `library-${row.group_id}`,
          name: row.group_name,
          selection_type: row.selection_type,
          min_select: row.min_select,
          max_select: row.max_select,
          is_required: row.is_required === 1,
          source: "library",
          hidden_when_option_ids:
            hiddenWhenByGroup.get(Number(row.group_id)) ?? [],
          options: [],
        };
        item.modifier_groups.push(group);
      }
      if (!group.options.some((option) => option.id === row.option_id)) {
        group.options.push({
          id: row.option_id,
          code: `library-${row.option_id}`,
          name: row.option_name,
          image_url: _resolveImageUrl(row.option_image_url),
          color_hex: row.option_color_hex,
          gradient_end_hex: row.option_gradient_end_hex,
          gradient_direction: row.option_gradient_direction || "diagonal",
          price_delta_rm: row.option_price_delta_rm,
          token_price_delta: row.option_token_price_delta,
          calorie_delta_kcal:
            optionCaloriesByItem.get(`${item.id}:${row.option_id}`) ??
            row.option_calorie_delta_kcal,
          is_default: row.option_is_default === 1,
        });
      }
    }
  }
  for (const item of itemsById.values()) {
    // Checkout treats the centralized option library as authoritative once
    // it applies to an item. Do not expose obsolete item-level choices that
    // would be rejected during payment.
    if (item.modifier_groups.some((group) => group.source === "library")) {
      item.modifier_groups = item.modifier_groups.filter(
        (group) => group.source === "library",
      );
    }
    item.modifier_groups = item.modifier_groups.filter(
      (group) => group.options.length > 0,
    );
  }

  for (const category of categories.values()) {
    category.items.sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { sensitivity: "base" }),
    );
  }

  return {
    store_id: storeId,
    categories: [...categories.values()],
  };
}

function _resolveImageUrl(imageUrl: string | null): string | null {
  if (!imageUrl) return null;
  if (imageUrl.startsWith("http://") || imageUrl.startsWith("https://")) {
    return imageUrl;
  }

  const baseOrigin = env.PUBLIC_API_BASE_URL.replace(/\/v1\/?$/, "");
  if (imageUrl.startsWith("/")) {
    return `${baseOrigin}${imageUrl}`;
  }

  return `${baseOrigin}/${imageUrl}`;
}

async function listActiveStores(userId: number): Promise<
  Array<{
    id: number;
    code: string;
    name: string;
    supports_pickup: boolean;
    pickup_lead_minutes: number;
    address_line_1: string | null;
    address_line_2: string | null;
    city: string | null;
    state: string | null;
    postcode: string | null;
    latitude: number | null;
    longitude: number | null;
    is_open_now: boolean;
    accepts_mobile_orders_now: boolean;
    mobile_ordering_status: "open" | "closing_soon" | "closed";
    mobile_order_cutoff_at: string | null;
    temporarily_closed: boolean;
    weekly_hours: ReturnType<typeof normalizeWeeklyHours>;
    status: "active" | "inactive";
  }>
> {
  const [rows] = await mysqlPool.query<Array<StoreRow>>(
    `
      SELECT
        s.id,
        s.code,
        s.name,
        s.status,
        s.supports_pickup,
        s.pickup_lead_minutes,
        s.address_line_1,
        s.address_line_2,
        s.city,
        s.state,
        s.postcode,
        s.latitude,
        s.longitude,
        s.timezone,
        s.temporarily_closed,
        s.weekly_hours_json
      FROM stores s
      JOIN customer_tenant_memberships ctm ON ctm.tenant_id = s.tenant_id
      JOIN admin_tenants t ON t.id = s.tenant_id AND t.status = 'active'
      WHERE s.status = 'active' AND s.is_customer_facing = 1 AND ctm.user_id = :userId
      ORDER BY s.name ASC, s.id ASC
    `,
    { userId },
  );

  const now = new Date();
  return rows.map((row) => {
    const mobileOrdering = getMobileOrderingStatus(row, now);
    return {
      id: row.id,
      code: row.code,
      name: row.name,
      supports_pickup: row.supports_pickup === 1,
      pickup_lead_minutes: row.pickup_lead_minutes,
      address_line_1: row.address_line_1,
      address_line_2: row.address_line_2,
      city: row.city,
      state: row.state,
      postcode: row.postcode,
      latitude: row.latitude == null ? null : Number(row.latitude),
      longitude: row.longitude == null ? null : Number(row.longitude),
      is_open_now: isStoreOpenNow(row, now),
      accepts_mobile_orders_now: isStoreAcceptingMobileOrdersNow(row, now),
      mobile_ordering_status: mobileOrdering.status,
      mobile_order_cutoff_at: mobileOrdering.cutoffAt,
      temporarily_closed: row.temporarily_closed === 1,
      weekly_hours: normalizeWeeklyHours(row.weekly_hours_json),
      status: row.status,
    };
  });
}

async function listActiveHomeBanners(userId: number): Promise<
  Array<{
    id: number;
    code: string;
    title: string;
    subtitle: string;
    image_source: string;
    media_type: "image" | "gif";
    animation_duration_ms: number;
    placement: "home" | "profile" | "both";
    sort_order: number;
    floating_priority: number;
    created_at: string;
  }>
> {
  const columns = await getHomeBannerColumns();
  const supportsTargeting = supportsHomeBannerTargeting(columns);
  const selectClause = buildHomeBannerSelectClause(columns);
  const homeOrderColumn = columns.has("home_sort_order")
    ? "hb.home_sort_order"
    : "hb.sort_order";
  const partnershipOrderColumn = columns.has("partnership_sort_order")
    ? "hb.partnership_sort_order"
    : "hb.sort_order";
  const bannerOrderExpression = supportsTargeting
    ? `CASE WHEN hb.banner_type = 'partner' THEN ${partnershipOrderColumn} ELSE ${homeOrderColumn} END`
    : homeOrderColumn;
  const whereClauses = ["hb.is_active = 1"];

  if (supportsTargeting) {
    whereClauses.push(
      "(hb.starts_at IS NULL OR hb.starts_at <= UTC_TIMESTAMP())",
    );
    whereClauses.push("(hb.ends_at IS NULL OR hb.ends_at > UTC_TIMESTAMP())");
  }

  const [rows] = await mysqlPool.query<Array<HomeBannerRow>>(
    `
      SELECT
        ${selectClause}
      FROM home_banners hb
      JOIN customer_tenant_memberships ctm
        ON ctm.tenant_id = hb.tenant_id AND ctm.user_id = :userId
      WHERE ${whereClauses.join(" AND ")}
      ORDER BY
        ${bannerOrderExpression} ASC,
        hb.id ASC
    `,
    { userId },
  );

  return rows
    .filter((row) => row.is_active === 1)
    .map((row) => ({
      id: row.id,
      code: row.code,
      title: row.title,
      subtitle: row.subtitle,
      image_source: row.image_source,
      media_type: row.media_type,
      animation_duration_ms: row.animation_duration_ms,
      banner_type: row.banner_type,
      partner_name: row.partner_name,
      sponsored_label: row.sponsored_label,
      cta_label: row.cta_label,
      action_type: row.action_type,
      action_value: row.action_value,
      destination_type: row.destination_type,
      secondary_destination_type: row.secondary_destination_type,
      target_value: row.target_value,
      starts_at: row.starts_at ? new Date(row.starts_at).toISOString() : null,
      ends_at: row.ends_at ? new Date(row.ends_at).toISOString() : null,
      placement: row.placement,
      sort_order: row.sort_order,
      home_sort_order: row.home_sort_order,
      floating_sort_order: row.floating_sort_order,
      partnership_sort_order: row.partnership_sort_order,
      floating_priority: row.floating_priority,
      created_at: new Date(row.created_at).toISOString(),
    }));
}
