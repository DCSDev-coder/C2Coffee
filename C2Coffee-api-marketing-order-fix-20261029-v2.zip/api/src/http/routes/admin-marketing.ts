import { randomUUID } from "node:crypto";
import type { FastifyInstance } from "fastify";
import type { ResultSetHeader, RowDataPacket } from "mysql2/promise";
import sharp from "sharp";
import { z } from "zod";
import { authenticateAdminRequest } from "../../admin/guard.js";
import { mysqlPool } from "../../db/mysql.js";
import { deliverPushToCustomerTenant } from "../../services/push-delivery.js";
import { ApiError } from "../errors.js";
import { saveMediaAsset } from "../../lib/media-assets.js";

const bannerTypeSchema = z.enum([
  "voucher",
  "event",
  "new_item",
  "general",
  "partner",
]);
const destinationTypeSchema = z.enum(["reward_section", "menu", "calendar"]);
const partnerActionTypeSchema = z.enum(["none", "external_url", "email"]);
const placementSchema = z.enum(["home", "profile", "both"]);
const mediaTypeSchema = z.enum(["image", "gif"]);
const marketingUploadSchema = z.object({
  file_name: z.string().trim().min(1).max(255),
  mime_type: z.enum(["image/png", "image/jpeg", "image/webp", "image/gif"]),
  data_url: z.string().trim().min(1),
  poster_kind: z.enum(["standard", "partner"]).optional().default("standard"),
});

const paymentMethodSchema = z.enum(["fpx", "duitnow_qr"]);
const customerMessageSchema = z.object({
  title: z.string().trim().min(1).max(120),
  body: z.string().trim().min(1).max(420),
  idempotency_key: z.string().uuid(),
});
const paymentServiceNoticeCreateSchema = z
  .object({
    title: z.string().trim().min(1).max(160).default("Payment service maintenance"),
    message: z.string().trim().min(1).max(600),
    payment_methods: z.array(paymentMethodSchema).min(1).max(2),
    starts_at: z.string().datetime({ offset: true }),
    ends_at: z.string().datetime({ offset: true }),
  })
  .superRefine((value, context) => {
    if (new Set(value.payment_methods).size !== value.payment_methods.length) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "Payment methods must be unique.", path: ["payment_methods"] });
    }
    const startsAt = new Date(value.starts_at).getTime();
    const endsAt = new Date(value.ends_at).getTime();
    if (endsAt <= startsAt) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "End time must be after start time.", path: ["ends_at"] });
    }
    if (endsAt <= Date.now()) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "End time must be in the future.", path: ["ends_at"] });
    }
  });

type PaymentServiceNoticeRow = RowDataPacket & {
  id: number;
  title: string;
  message: string;
  payment_methods_json: string | string[];
  starts_at: Date;
  ends_at: Date;
  status: "active" | "cancelled";
  created_at: Date;
  updated_at: Date;
};

function paymentMethodsFromJson(value: string | string[]): string[] {
  if (Array.isArray(value)) return value.filter((item) => paymentMethodSchema.safeParse(item).success);
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed)
      ? parsed.filter((item): item is string => paymentMethodSchema.safeParse(item).success)
      : [];
  } catch {
    return [];
  }
}

function paymentServiceNoticeResponse(row: PaymentServiceNoticeRow) {
  return {
    id: row.id,
    title: row.title,
    message: row.message,
    payment_methods: paymentMethodsFromJson(row.payment_methods_json),
    starts_at: row.starts_at.toISOString(),
    ends_at: row.ends_at.toISOString(),
    status: row.status,
    created_at: row.created_at.toISOString(),
    updated_at: row.updated_at.toISOString(),
  };
}

const bannerCreateSchema = z.object({
  title: z.string().trim().min(1).max(255),
  subtitle: z.string().trim().min(1).max(512),
  imageSource: z.string().trim().min(1).max(512),
  mediaType: mediaTypeSchema.optional().default("image"),
  animationDurationMs: z.coerce
    .number()
    .int()
    .min(0)
    .max(30_000)
    .optional()
    .default(0),
  bannerType: bannerTypeSchema,
  partnerName: z.string().trim().max(160).nullable().optional().default(null),
  sponsoredLabel: z.coerce.boolean().optional().default(true),
  ctaLabel: z.string().trim().max(60).nullable().optional().default(null),
  actionType: partnerActionTypeSchema.optional().default("none"),
  actionValue: z.string().trim().max(512).nullable().optional().default(null),
  destinationType: destinationTypeSchema.optional().default("menu"),
  secondaryDestinationType: destinationTypeSchema
    .nullable()
    .optional()
    .default(null),
  targetValue: z.string().trim().max(120).nullable().optional().default(null),
  startsAt: z.string().trim().nullable().optional().default(null),
  endsAt: z.string().trim().nullable().optional().default(null),
  placement: placementSchema.optional().default("both"),
  sortOrder: z.coerce.number().int().min(0).max(9999).optional(),
  floatingPriority: z.coerce.boolean().optional().default(false),
  isActive: z.coerce.boolean().optional().default(true),
});

const bannerUpdateSchema = z.object({
  title: z.string().trim().min(1).max(255).optional(),
  subtitle: z.string().trim().min(1).max(512).optional(),
  imageSource: z.string().trim().min(1).max(512).optional(),
  mediaType: mediaTypeSchema.optional(),
  animationDurationMs: z.coerce.number().int().min(0).max(30_000).optional(),
  bannerType: bannerTypeSchema.optional(),
  partnerName: z.string().trim().max(160).nullable().optional(),
  sponsoredLabel: z.coerce.boolean().optional(),
  ctaLabel: z.string().trim().max(60).nullable().optional(),
  actionType: partnerActionTypeSchema.optional(),
  actionValue: z.string().trim().max(512).nullable().optional(),
  destinationType: destinationTypeSchema.optional(),
  secondaryDestinationType: destinationTypeSchema.nullable().optional(),
  targetValue: z.string().trim().max(120).nullable().optional(),
  startsAt: z.string().trim().nullable().optional(),
  endsAt: z.string().trim().nullable().optional(),
  placement: placementSchema.optional(),
  sortOrder: z.coerce.number().int().min(0).max(9999).optional(),
  floatingPriority: z.coerce.boolean().optional(),
  isActive: z.coerce.boolean().optional(),
});

const bannerReorderSchema = z.object({
  bannerIds: z.array(z.coerce.number().int().positive()).min(1).max(500),
});
const bannerSurfaceReorderSchema = z.object({
  surface: z.enum(["home", "floating", "partnership"]),
  bannerIds: z.array(z.coerce.number().int().positive()).min(1).max(500),
});

type BannerRow = RowDataPacket & {
  id: number;
  code: string;
  title: string;
  subtitle: string;
  image_source: string;
  media_type: "image" | "gif";
  animation_duration_ms: number;
  banner_type: string;
  partner_name: string | null;
  sponsored_label: number;
  cta_label: string | null;
  action_type: "none" | "external_url" | "email";
  action_value: string | null;
  destination_type: string;
  secondary_destination_type: string | null;
  target_value: string | null;
  starts_at: Date | string | null;
  ends_at: Date | string | null;
  placement: "home" | "profile" | "both";
  sort_order: number;
  home_sort_order: number;
  floating_sort_order: number;
  partnership_sort_order: number;
  floating_priority: number;
  is_active: number;
  created_at: Date | string;
  updated_at: Date | string;
  menu_item_name: string | null;
  voucher_name: string | null;
};

type DestinationType = "reward_section" | "menu" | "calendar";

let homeBannerColumnsPromise: Promise<Set<string>> | null = null;
let hasBannerEngagementsPromise: Promise<boolean> | null = null;

async function getHomeBannerColumns(): Promise<Set<string>> {
  if (!homeBannerColumnsPromise) {
    homeBannerColumnsPromise = mysqlPool
      .query<Array<RowDataPacket>>("SHOW COLUMNS FROM home_banners")
      .then(
        ([rows]) =>
          new Set(
            rows
              .map((row) =>
                String((row as { Field?: string }).Field ?? "").trim(),
              )
              .filter(Boolean),
          ),
      );
  }

  return homeBannerColumnsPromise;
}

async function hasBannerEngagementsTable(): Promise<boolean> {
  if (!hasBannerEngagementsPromise) {
    hasBannerEngagementsPromise = mysqlPool
      .query<Array<RowDataPacket>>("SHOW TABLES LIKE 'home_banner_engagements'")
      .then(([rows]) => rows.length > 0);
  }
  return hasBannerEngagementsPromise;
}

function supportsHomeBannerTargeting(columns: Set<string>): boolean {
  return [
    "banner_type",
    "destination_type",
    "secondary_destination_type",
    "target_value",
    "starts_at",
    "ends_at",
  ].every((column) => columns.has(column));
}

function supportsHomeBannerFloatingPriority(columns: Set<string>): boolean {
  return columns.has("floating_priority");
}

function supportsHomeBannerSurfaceOrders(columns: Set<string>): boolean {
  return ["home_sort_order", "floating_sort_order", "partnership_sort_order"].every(
    (column) => columns.has(column),
  );
}

function supportsHomeBannerMedia(columns: Set<string>): boolean {
  return columns.has("media_type") && columns.has("animation_duration_ms");
}

function supportsPartnerCampaignFields(columns: Set<string>): boolean {
  return [
    "partner_name",
    "sponsored_label",
    "cta_label",
    "action_type",
    "action_value",
  ].every((column) => columns.has(column));
}

function buildHomeBannerSelectClause(columns: Set<string>): string {
  const selects = [
    "hb.id",
    "hb.code",
    "hb.title",
    "hb.subtitle",
    "hb.image_source",
    supportsHomeBannerMedia(columns)
      ? "hb.media_type"
      : "'image' AS media_type",
    supportsHomeBannerMedia(columns)
      ? "hb.animation_duration_ms"
      : "0 AS animation_duration_ms",
  ];

  if (supportsHomeBannerTargeting(columns)) {
    selects.push(
      "hb.banner_type",
      "hb.destination_type",
      "hb.secondary_destination_type",
      `CASE
        WHEN hb.banner_type = 'voucher' AND vt.code IS NOT NULL THEN vt.code
        ELSE hb.target_value
      END AS target_value`,
      "hb.starts_at",
      "hb.ends_at",
    );
  } else {
    selects.push(
      "'general' AS banner_type",
      "'menu' AS destination_type",
      "NULL AS secondary_destination_type",
      "NULL AS target_value",
      "NULL AS starts_at",
      "NULL AS ends_at",
    );
  }

  if (supportsPartnerCampaignFields(columns)) {
    selects.push(
      "hb.partner_name",
      "hb.sponsored_label",
      "hb.cta_label",
      "hb.action_type",
      "hb.action_value",
    );
  } else {
    selects.push(
      "NULL AS partner_name",
      "1 AS sponsored_label",
      "NULL AS cta_label",
      "'none' AS action_type",
      "NULL AS action_value",
    );
  }

  selects.push(
    "hb.placement",
    "hb.sort_order",
    columns.has("home_sort_order")
      ? "hb.home_sort_order"
      : "hb.sort_order AS home_sort_order",
    columns.has("floating_sort_order")
      ? "hb.floating_sort_order"
      : "hb.sort_order AS floating_sort_order",
    columns.has("partnership_sort_order")
      ? "hb.partnership_sort_order"
      : "hb.sort_order AS partnership_sort_order",
    supportsHomeBannerFloatingPriority(columns)
      ? "hb.floating_priority"
      : "0 AS floating_priority",
    "hb.is_active",
    "hb.created_at",
    "hb.updated_at",
  );

  if (supportsHomeBannerTargeting(columns)) {
    selects.push("mi.name AS menu_item_name", "vt.name AS voucher_name");
  } else {
    selects.push("NULL AS menu_item_name", "NULL AS voucher_name");
  }
  return selects.join(",\n          ");
}

function buildHomeBannerJoinClause(columns: Set<string>): string {
  if (!supportsHomeBannerTargeting(columns)) {
    return `
      LEFT JOIN menu_items mi
        ON 1 = 0
      LEFT JOIN voucher_templates vt
        ON 1 = 0
    `;
  }

  return `
    LEFT JOIN menu_items mi
      ON hb.banner_type = 'new_item'
     AND mi.code = hb.target_value
    LEFT JOIN voucher_templates vt
      ON hb.banner_type = 'voucher'
     AND (vt.code = hb.target_value OR CAST(vt.id AS CHAR) = hb.target_value)
     AND vt.tenant_id = hb.tenant_id
  `;
}

function buildHomeBannerInsertParts(columns: Set<string>): {
  columns: string[];
  values: string[];
} {
  const insertColumns = [
    "tenant_id",
    "code",
    "title",
    "subtitle",
    "image_source",
  ];
  const insertValues = [
    ":tenantId",
    ":code",
    ":title",
    ":subtitle",
    ":imageSource",
  ];

  if (supportsHomeBannerMedia(columns)) {
    insertColumns.push("media_type", "animation_duration_ms");
    insertValues.push(":mediaType", ":animationDurationMs");
  }

  if (supportsHomeBannerTargeting(columns)) {
    insertColumns.push(
      "banner_type",
      "destination_type",
      "secondary_destination_type",
      "target_value",
      "starts_at",
      "ends_at",
    );
    insertValues.push(
      ":bannerType",
      ":destinationType",
      ":secondaryDestinationType",
      ":targetValue",
      ":startsAt",
      ":endsAt",
    );
  }

  if (supportsPartnerCampaignFields(columns)) {
    insertColumns.push(
      "partner_name",
      "sponsored_label",
      "cta_label",
      "action_type",
      "action_value",
    );
    insertValues.push(
      ":partnerName",
      ":sponsoredLabel",
      ":ctaLabel",
      ":actionType",
      ":actionValue",
    );
  }

  if (supportsHomeBannerFloatingPriority(columns)) {
    insertColumns.push("floating_priority");
    insertValues.push(":floatingPriority");
  }

  insertColumns.push(
    "placement",
    "sort_order",
    "is_active",
    "created_at",
    "updated_at",
  );
  insertValues.push(
    ":placement",
    ":sortOrder",
    ":isActive",
    "UTC_TIMESTAMP()",
    "UTC_TIMESTAMP()",
  );

  if (supportsHomeBannerSurfaceOrders(columns)) {
    insertColumns.splice(-3, 0, "home_sort_order", "floating_sort_order", "partnership_sort_order");
    insertValues.splice(-3, 0, ":homeSortOrder", ":floatingSortOrder", ":partnershipSortOrder");
  }

  return {
    columns: insertColumns,
    values: insertValues,
  };
}

function readGifTimeline(buffer: Buffer): {
  width: number;
  height: number;
  durationMs: number;
} {
  if (
    buffer.length < 13 ||
    (buffer.subarray(0, 6).toString("ascii") !== "GIF87a" &&
      buffer.subarray(0, 6).toString("ascii") !== "GIF89a")
  ) {
    throw new ApiError(400, "invalid_gif", "Please upload a valid GIF poster.");
  }

  const width = buffer.readUInt16LE(6);
  const height = buffer.readUInt16LE(8);
  let position = 13;
  if (buffer[10] & 0x80) {
    position += 3 * (1 << ((buffer[10] & 0x07) + 1));
  }

  let pendingDelayMs = 100;
  let durationMs = 0;
  let frames = 0;
  const skipSubBlocks = (): void => {
    while (position < buffer.length) {
      const size = buffer[position++];
      if (size === 0) return;
      position += size;
    }
  };

  while (position < buffer.length) {
    const marker = buffer[position++];
    if (marker === 0x3b) break;
    if (marker === 0x21) {
      const label = buffer[position++];
      if (
        label === 0xf9 &&
        buffer[position] === 0x04 &&
        position + 5 < buffer.length
      ) {
        position += 2;
        pendingDelayMs = Math.max(buffer.readUInt16LE(position) * 10, 100);
        position += 4;
      } else {
        skipSubBlocks();
      }
      continue;
    }
    if (marker !== 0x2c || position + 8 >= buffer.length) {
      throw new ApiError(400, "invalid_gif", "GIF poster data is incomplete.");
    }
    position += 8;
    const packed = buffer[position++];
    if (packed & 0x80) position += 3 * (1 << ((packed & 0x07) + 1));
    position += 1;
    skipSubBlocks();
    durationMs += pendingDelayMs;
    pendingDelayMs = 100;
    frames++;
  }

  if (frames === 0 || durationMs > 30_000) {
    throw new ApiError(
      400,
      "invalid_gif_duration",
      "GIF posters must contain frames and complete within 30 seconds.",
    );
  }
  return { width, height, durationMs };
}

function buildHomeBannerUpdateFields(columns: Set<string>): string[] {
  const fields = [
    "title = :title",
    "subtitle = :subtitle",
    "image_source = :imageSource",
    "placement = :placement",
    "sort_order = :sortOrder",
  ];

  if (supportsHomeBannerTargeting(columns)) {
    fields.splice(
      3,
      0,
      "banner_type = :bannerType",
      "destination_type = :destinationType",
      "secondary_destination_type = :secondaryDestinationType",
      "target_value = :targetValue",
      "starts_at = :startsAt",
      "ends_at = :endsAt",
    );
  }

  if (supportsHomeBannerFloatingPriority(columns)) {
    fields.push("floating_priority = :floatingPriority");
  }

  fields.push("is_active = :isActive");
  fields.push("updated_at = UTC_TIMESTAMP()");
  return fields;
}

async function getNextHomeBannerSortOrder(tenantId: number): Promise<number> {
  const [rows] = await mysqlPool.query<
    Array<RowDataPacket & { max_sort_order: number | null }>
  >(
    `
      SELECT COALESCE(MAX(sort_order), 0) + 10 AS max_sort_order
      FROM home_banners
      WHERE tenant_id = :tenantId
    `,
    { tenantId },
  );

  return Number(rows[0]?.max_sort_order ?? 10) || 10;
}

function requireMarketingAccess(request: {
  adminAuth?: { roles: string[] };
}): void {
  const roles = request.adminAuth?.roles || [];
  if (!roles.includes("super_admin") && !roles.includes("marketing_admin")) {
    throw new ApiError(
      403,
      "admin_forbidden",
      "You do not have permission to perform this action.",
    );
  }
}

function toUtcDateTimeString(
  input: string | Date | null | undefined,
): string | null {
  if (!input) {
    return null;
  }

  const date = input instanceof Date ? input : new Date(input);
  if (Number.isNaN(date.getTime())) {
    return null;
  }

  return date.toISOString().slice(0, 19).replace("T", " ");
}

function formatDestinationLabel(destinationType: string): string {
  switch (destinationType as DestinationType) {
    case "reward_section":
      return "Reward section";
    case "calendar":
      return "Calendar";
    case "menu":
    default:
      return "Menu";
  }
}

function formatBannerStatus(row: BannerRow): string {
  if (row.is_active !== 1) {
    return "Inactive";
  }

  if (!row.starts_at && !row.ends_at) {
    return "Active";
  }

  const now = Date.now();
  const startsAt = row.starts_at
    ? new Date(row.starts_at).getTime()
    : Number.NaN;
  const endsAt = row.ends_at ? new Date(row.ends_at).getTime() : Number.NaN;

  if (!Number.isNaN(startsAt) && now < startsAt) {
    return "Scheduled";
  }
  if (!Number.isNaN(endsAt) && now > endsAt) {
    return "Ended";
  }

  return "Live";
}

function formatDateTimeLabel(value: Date | string | null): string {
  if (!value) {
    return "";
  }

  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "";
  }

  return new Intl.DateTimeFormat("en-MY", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

function buildBannerCode(title: string): string {
  const slug =
    title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 32) || "banner";
  return `banner-${slug}-${randomUUID().slice(0, 8)}`;
}

function normalizeRequestBody(
  body: z.infer<typeof bannerCreateSchema> | z.infer<typeof bannerUpdateSchema>,
) {
  const bannerType = body.bannerType ?? "general";
  const isEvent = bannerType === "event" || body.destinationType === "calendar";
  const normalizedBannerType = isEvent ? "event" : bannerType;
  const isVoucher = bannerType === "voucher";
  const isNewItem = bannerType === "new_item";
  const isPartner = bannerType === "partner";

  const destinationType = isEvent
    ? "calendar"
    : isNewItem
      ? "menu"
      : (body.destinationType ?? "menu");

  const secondaryDestinationType = isEvent ? "menu" : null;

  const targetValue =
    isVoucher || isNewItem ? String(body.targetValue ?? "").trim() : null;
  const startsAt =
    isEvent || isPartner ? toUtcDateTimeString(body.startsAt ?? null) : null;
  const endsAt =
    isEvent || isPartner ? toUtcDateTimeString(body.endsAt ?? null) : null;

  const actionType = isPartner ? (body.actionType ?? "none") : "none";
  const actionValue =
    isPartner && actionType !== "none"
      ? String(body.actionValue ?? "").trim()
      : null;

  return {
    bannerType: normalizedBannerType,
    partnerName: isPartner
      ? String(body.partnerName ?? "").trim() || null
      : null,
    sponsoredLabel: isPartner ? (body.sponsoredLabel ?? true) : false,
    ctaLabel:
      isPartner && actionType !== "none"
        ? String(body.ctaLabel ?? "").trim() || "Learn more"
        : null,
    actionType,
    actionValue: actionValue || null,
    destinationType,
    secondaryDestinationType,
    targetValue: targetValue || null,
    startsAt,
    endsAt,
    placement: isPartner ? "home" : (body.placement ?? "both"),
    sortOrder: body.sortOrder ?? null,
    floatingPriority: isPartner ? false : (body.floatingPriority ?? null),
    isActive: body.isActive ?? true,
  };
}

function validatePartnerAction(
  input: ReturnType<typeof normalizeRequestBody>,
): void {
  if (input.bannerType !== "partner") return;
  if (!input.partnerName) {
    throw new ApiError(
      400,
      "missing_partner_name",
      "Partnership requires a partner or business name.",
    );
  }
  if (input.actionType === "none") {
    throw new ApiError(
      400,
      "missing_partner_action",
      "Partnership requires a website or email action.",
    );
  }
  if (!input.actionValue) {
    throw new ApiError(
      400,
      "missing_partner_action",
      "Enter the website or email address for this partner action.",
    );
  }
  if (input.actionType === "external_url") {
    let url: URL;
    try {
      url = new URL(input.actionValue);
    } catch {
      throw new ApiError(
        400,
        "invalid_partner_url",
        "Partner website must be a valid HTTPS URL.",
      );
    }
    if (url.protocol !== "https:" || url.username || url.password) {
      throw new ApiError(
        400,
        "invalid_partner_url",
        "Partner website must be a valid HTTPS URL without embedded credentials.",
      );
    }
  }
  if (
    input.actionType === "email" &&
    !z.string().email().safeParse(input.actionValue).success
  ) {
    throw new ApiError(
      400,
      "invalid_partner_email",
      "Enter a valid partner email address.",
    );
  }
}

function publicPosterNotificationText(
  value: string,
  fallback: string,
  maximumLength: number,
): string {
  const text = String(value ?? "")
    .replace(/[\u0000-\u001F\u007F]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return text ? text.slice(0, maximumLength) : fallback;
}

function isBannerNotifiable(
  row: Pick<BannerRow, "is_active" | "banner_type" | "starts_at" | "ends_at">,
): boolean {
  if (row.is_active !== 1) return false;
  const now = Date.now();
  const startsAt = row.starts_at
    ? new Date(row.starts_at).getTime()
    : Number.NaN;
  const endsAt = row.ends_at ? new Date(row.ends_at).getTime() : Number.NaN;
  if (!Number.isNaN(startsAt) && startsAt > now) return false;
  if (!Number.isNaN(endsAt) && endsAt <= now) return false;
  return (
    row.banner_type !== "event" ||
    (!Number.isNaN(startsAt) && !Number.isNaN(endsAt))
  );
}

async function notifyCustomersAboutPoster(input: {
  banner: BannerRow;
  tenantId: number;
  log: {
    info: (payload: unknown, message: string) => void;
    warn: (payload: unknown, message: string) => void;
  };
}): Promise<{
  recipients: number;
  attemptedDevices: number;
  deliveredDevices: number;
  failedDevices: number;
}> {
  const title = publicPosterNotificationText(
    input.banner.title,
    "New update from C2 Coffee",
    120,
  );
  const body = publicPosterNotificationText(
    input.banner.subtitle,
    "A new offer is available in the C2 Coffee app.",
    180,
  );
  const data = {
    type: "marketing_poster",
    banner_id: String(input.banner.id),
    banner_code: input.banner.code,
    destination: input.banner.destination_type,
  };

  const [result] = await mysqlPool.execute<ResultSetHeader>(
    `
      INSERT INTO notifications (user_id, type, title, body, data_json, sent_at, created_at)
      SELECT ctm.user_id, 'marketing_poster', :title, :body, :dataJson, UTC_TIMESTAMP(), UTC_TIMESTAMP()
      FROM customer_tenant_memberships ctm
      JOIN users u ON u.id = ctm.user_id
      LEFT JOIN customer_notification_preferences cnp ON cnp.user_id = ctm.user_id
      WHERE ctm.tenant_id = :tenantId
        AND u.status = 'active'
        AND COALESCE(cnp.marketing_enabled, 1) = 1
    `,
    {
      tenantId: input.tenantId,
      title,
      body,
      dataJson: JSON.stringify(data),
    },
  );

  try {
    const delivery = await deliverPushToCustomerTenant({
      tenantId: input.tenantId,
      title,
      body,
      data,
    });
    const resultSummary = {
      recipients: result.affectedRows,
      attemptedDevices: delivery.attemptedTokens,
      deliveredDevices: delivery.deliveredTokens,
      failedDevices: delivery.failedTokens,
    };
    input.log.info(
      {
        bannerId: input.banner.id,
        ...resultSummary,
        invalidDevices: delivery.invalidTokens,
        failureReasons: delivery.failureReasons,
      },
      "Poster push delivery completed.",
    );
    return resultSummary;
  } catch (error) {
    input.log.warn(
      { err: error, bannerId: input.banner.id },
      "Poster push delivery failed after notification creation.",
    );
    return {
      recipients: result.affectedRows,
      attemptedDevices: 0,
      deliveredDevices: 0,
      failedDevices: 0,
    };
  }
}

export async function registerAdminMarketingRoutes(
  app: FastifyInstance,
): Promise<void> {
  app.post(
    "/v1/admin/marketing/customer-messages",
    {
      preHandler: authenticateAdminRequest,
      config: { rateLimit: { max: 5, timeWindow: "1 hour" } },
    },
    async (request) => {
      requireMarketingAccess(request);
      const payload = customerMessageSchema.parse(request.body);
      const deliveryKey = `admin-message:${request.adminAuth.tenantId}:${payload.idempotency_key}`;
      // Reuse the established marketing-poster push route so customer
      // broadcasts work with app versions released before the standalone
      // inbox message type was introduced. The persisted inbox record remains
      // `customer_message`; only the device navigation hint uses the proven
      // notification route.
      const data = {
        type: "marketing_poster",
        message_kind: "customer_message",
        source: "admin_marketing",
        destination: "notifications",
      };
      const connection = await mysqlPool.getConnection();
      let recipients = 0;
      let idempotentReplay = false;
      try {
        await connection.beginTransaction();
        const [existingDelivery] = await connection.execute<RowDataPacket[]>(
          `SELECT id FROM notifications
           WHERE type = 'customer_message' AND delivery_key = :deliveryKey
           LIMIT 1 FOR UPDATE`,
          { deliveryKey },
        );
        idempotentReplay = existingDelivery.length > 0;
        const [result] = idempotentReplay
          ? [{ affectedRows: 0 } as ResultSetHeader]
          : await connection.execute<ResultSetHeader>(
          `
            INSERT INTO notifications (
              user_id, type, title, body, data_json, delivery_key, sent_at, created_at
            )
            SELECT ctm.user_id, 'customer_message', :title, :body, :dataJson,
                   :deliveryKey, UTC_TIMESTAMP(), UTC_TIMESTAMP()
            FROM customer_tenant_memberships ctm
            JOIN users u ON u.id = ctm.user_id
            LEFT JOIN customer_notification_preferences cnp
              ON cnp.user_id = ctm.user_id
            WHERE ctm.tenant_id = :tenantId
              AND u.status = 'active'
              AND COALESCE(cnp.marketing_enabled, 1) = 1
            ON DUPLICATE KEY UPDATE delivery_key = VALUES(delivery_key)
          `,
          {
            tenantId: request.adminAuth.tenantId,
            title: payload.title,
            body: payload.body,
            dataJson: JSON.stringify(data),
            deliveryKey,
          },
        );
        recipients = result.affectedRows;
        if (recipients > 0) {
          await connection.execute(
            `INSERT INTO admin_audit_logs (
               admin_user_id, effective_roles_json, action_code, target_type,
               after_json, ip_address, user_agent, created_at
             ) VALUES (
               :adminUserId, :roles, 'customer_message_broadcast', 'customer_notification',
               :afterJson, :ipAddress, :userAgent, UTC_TIMESTAMP()
             )`,
            {
              adminUserId: request.adminAuth.adminUserId,
              roles: JSON.stringify(request.adminAuth.roles),
              afterJson: JSON.stringify({
                tenant_id: request.adminAuth.tenantId,
                title: payload.title,
                recipients,
                delivery_key: deliveryKey,
              }),
              ipAddress: request.ip,
              userAgent: request.headers["user-agent"] ?? null,
            },
          );
        }
        await connection.commit();
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }

      let delivery = {
        attemptedTokens: 0,
        deliveredTokens: 0,
        failedTokens: 0,
        attemptedByPlatform: { android: 0, ios: 0 },
        acceptedByPlatform: { android: 0, ios: 0 },
      };
      try {
        // An idempotent replay has no new inbox rows and must not send push
        // notifications a second time.
        if (idempotentReplay || recipients === 0) {
          return {
            success: true,
            idempotent_replay: idempotentReplay,
            message: {
              recipients: 0,
              attemptedDevices: 0,
              deliveredDevices: 0,
              failedDevices: 0,
              acceptedByPlatform: { android: 0, ios: 0 },
            },
          };
        }
        const pushResult = await deliverPushToCustomerTenant({
          tenantId: request.adminAuth.tenantId,
          title: payload.title,
          body: payload.body,
          data,
        });
        delivery = {
          attemptedTokens: pushResult.attemptedTokens,
          deliveredTokens: pushResult.deliveredTokens,
          failedTokens: pushResult.failedTokens,
          attemptedByPlatform: pushResult.attemptedByPlatform,
          acceptedByPlatform: pushResult.acceptedByPlatform,
        };
      } catch (error) {
        request.log.warn({ err: error }, "Standalone customer push delivery failed after notification creation.");
      }

      request.log.info(
        {
          recipients,
          attemptedDevices: delivery.attemptedTokens,
          deliveredDevices: delivery.deliveredTokens,
          failedDevices: delivery.failedTokens,
          attemptedByPlatform: delivery.attemptedByPlatform,
          acceptedByPlatform: delivery.acceptedByPlatform,
        },
        "Standalone customer message sent.",
      );

      return {
        success: true,
        message: {
          recipients,
          attemptedDevices: delivery.attemptedTokens,
          deliveredDevices: delivery.deliveredTokens,
          failedDevices: delivery.failedTokens,
          acceptedByPlatform: delivery.acceptedByPlatform,
        },
      };
    },
  );

  app.get(
    "/v1/admin/marketing/payment-service-notices",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);
      const [rows] = await mysqlPool.query<PaymentServiceNoticeRow[]>(
        `SELECT id, title, message, payment_methods_json, starts_at, ends_at, status, created_at, updated_at
         FROM payment_service_notices
         WHERE tenant_id = :tenantId
         ORDER BY status = 'active' DESC, ends_at DESC, id DESC
         LIMIT 100`,
        { tenantId: request.adminAuth.tenantId },
      );
      return { notices: rows.map(paymentServiceNoticeResponse) };
    },
  );

  app.post(
    "/v1/admin/marketing/payment-service-notices",
    { preHandler: authenticateAdminRequest },
    async (request, reply) => {
      requireMarketingAccess(request);
      const payload = paymentServiceNoticeCreateSchema.parse(request.body);
      const startsAt = toUtcDateTimeString(payload.starts_at);
      const endsAt = toUtcDateTimeString(payload.ends_at);
      if (!startsAt || !endsAt) {
        throw new ApiError(400, "invalid_maintenance_window", "Enter a valid maintenance start and end time.");
      }

      const connection = await mysqlPool.getConnection();
      let committed = false;
      let noticeId = 0;
      try {
        await connection.beginTransaction();
        const [result] = await connection.execute<ResultSetHeader>(
          `INSERT INTO payment_service_notices
             (tenant_id, title, message, payment_methods_json, starts_at, ends_at, status, created_by_admin_id, created_at, updated_at)
           VALUES
             (:tenantId, :title, :message, :paymentMethods, :startsAt, :endsAt, 'active', :adminUserId, UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
          {
            tenantId: request.adminAuth.tenantId,
            title: payload.title,
            message: payload.message,
            paymentMethods: JSON.stringify(payload.payment_methods),
            startsAt,
            endsAt,
            adminUserId: request.adminAuth.adminUserId,
          },
        );
        noticeId = result.insertId;
        await connection.execute(
          `INSERT INTO admin_audit_logs
             (admin_user_id, effective_roles_json, action_code, target_type, target_id, after_json, ip_address, user_agent, created_at)
           VALUES
             (:adminUserId, :roles, 'payment_service_notice_created', 'payment_service_notice', :noticeId,
              :afterJson, :ipAddress, :userAgent, UTC_TIMESTAMP())`,
          {
            adminUserId: request.adminAuth.adminUserId,
            roles: JSON.stringify(request.adminAuth.roles),
            noticeId,
            afterJson: JSON.stringify({
              title: payload.title,
              message: payload.message,
              payment_methods: payload.payment_methods,
              starts_at: payload.starts_at,
              ends_at: payload.ends_at,
            }),
            ipAddress: request.ip,
            userAgent: request.headers["user-agent"] ?? null,
          },
        );
        await connection.commit();
        committed = true;
      } catch (error) {
        if (!committed) await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }

      let delivery = null;
      try {
        delivery = await deliverPushToCustomerTenant({
          tenantId: request.adminAuth.tenantId,
          title: payload.title,
          body: payload.message,
          data: { type: "payment_service_notice", notice_id: String(noticeId) },
          respectMarketingPreference: false,
        });
      } catch (error) {
        request.log.warn(
          { noticeId, error: error instanceof Error ? error.message : String(error) },
          "Payment service notice was saved but push delivery failed.",
        );
      }

      return reply.code(201).send({ notice_id: noticeId, delivery });
    },
  );

  app.post(
    "/v1/admin/marketing/payment-service-notices/:id/cancel",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);
      const noticeId = z.coerce.number().int().positive().parse((request.params as { id: string }).id);
      const [result] = await mysqlPool.execute<ResultSetHeader>(
        `UPDATE payment_service_notices
         SET status = 'cancelled', cancelled_by_admin_id = :adminUserId,
             cancelled_at = UTC_TIMESTAMP(), updated_at = UTC_TIMESTAMP()
         WHERE id = :noticeId AND tenant_id = :tenantId AND status = 'active'`,
        {
          noticeId,
          tenantId: request.adminAuth.tenantId,
          adminUserId: request.adminAuth.adminUserId,
        },
      );
      if (result.affectedRows === 0) {
        throw new ApiError(404, "payment_service_notice_not_found", "Active payment service notice was not found.");
      }
      await mysqlPool.execute(
        `INSERT INTO admin_audit_logs
           (admin_user_id, effective_roles_json, action_code, target_type, target_id, ip_address, user_agent, created_at)
         VALUES
           (:adminUserId, :roles, 'payment_service_notice_cancelled', 'payment_service_notice', :noticeId,
            :ipAddress, :userAgent, UTC_TIMESTAMP())`,
        {
          adminUserId: request.adminAuth.adminUserId,
          roles: JSON.stringify(request.adminAuth.roles),
          noticeId,
          ipAddress: request.ip,
          userAgent: request.headers["user-agent"] ?? null,
        },
      );
      return { cancelled: true };
    },
  );

  app.post(
    "/v1/admin/marketing/uploads",
    {
      preHandler: authenticateAdminRequest,
      bodyLimit: 30 * 1024 * 1024,
    },
    async (request) => {
      requireMarketingAccess(request);
      const payload = marketingUploadSchema.parse(request.body);
      const base64Payload = payload.data_url.includes("base64,")
        ? payload.data_url.split("base64,").pop() || ""
        : payload.data_url;
      const content = Buffer.from(base64Payload, "base64");
      if (content.length === 0 || content.length > 15 * 1024 * 1024) {
        throw new ApiError(
          400,
          "invalid_poster_upload",
          "Poster files must be between 1 byte and 15 MB.",
        );
      }

      if (payload.mime_type === "image/gif") {
        const gif = readGifTimeline(content);
        const expectedRatio =
          payload.poster_kind === "partner" ? 16 / 9 : 4 / 5;
        if (Math.abs(gif.width / gif.height - expectedRatio) > 0.02) {
          throw new ApiError(
            400,
            "invalid_gif_aspect_ratio",
            payload.poster_kind === "partner"
              ? "Partner GIF posters must use a 16:9 ratio, such as 1200 x 675 pixels."
              : "GIF posters must use a 4:5 portrait ratio, such as 1080 x 1350 pixels.",
          );
        }
        const uploadName = `${Date.now()}-${randomUUID()}.gif`;
        const assetPath = `/assets/marketing/uploads/${uploadName}`;
        await saveMediaAsset({
          assetPath,
          fileName: uploadName,
          mimeType: "image/gif",
          content,
        });
        return {
          image_url: assetPath,
          media_type: "gif",
          animation_duration_ms: gif.durationMs,
        };
      }

      let optimizedContent: Buffer;
      try {
        const targetSize =
          payload.poster_kind === "partner"
            ? { width: 1200, height: 675 }
            : { width: 1080, height: 1350 };
        optimizedContent = await sharp(content, {
          limitInputPixels: 32_000_000,
        })
          .rotate()
          .resize({ ...targetSize, fit: "cover", position: "attention" })
          .webp({ quality: 84, effort: 4 })
          .toBuffer();
      } catch {
        throw new ApiError(
          400,
          "invalid_poster_upload",
          "Upload a valid PNG, JPEG, WebP, or GIF poster. Video files are not supported.",
        );
      }
      const uploadName = `${Date.now()}-${randomUUID()}.webp`;
      const assetPath = `/assets/marketing/uploads/${uploadName}`;
      await saveMediaAsset({
        assetPath,
        fileName: uploadName,
        mimeType: "image/webp",
        content: optimizedContent,
      });
      return {
        image_url: assetPath,
        media_type: "image",
        animation_duration_ms: 0,
      };
    },
  );

  app.get(
    "/v1/admin/marketing/banners",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);

      const query =
        typeof request.query === "object" && request.query !== null
          ? (request.query as {
              search?: string;
              banner_type?: string;
              placement?: string;
              is_active?: string;
            })
          : {};

      const searchTerm = String(query.search ?? "")
        .trim()
        .toLowerCase();
      const bannerType = String(query.banner_type ?? "")
        .trim()
        .toLowerCase();
      const placement = String(query.placement ?? "")
        .trim()
        .toLowerCase();
      const isActive = String(query.is_active ?? "").trim();
      const columns = await getHomeBannerColumns();
      const supportsTargeting = supportsHomeBannerTargeting(columns);

      if (supportsTargeting) {
        await mysqlPool.execute(
          `
          UPDATE home_banners
          SET is_active = 0,
              updated_at = UTC_TIMESTAMP()
          WHERE banner_type IN ('event', 'partner')
            AND tenant_id = :tenantId
            AND is_active = 1
            AND ends_at IS NOT NULL
            AND ends_at <= UTC_TIMESTAMP()
        `,
          { tenantId: request.adminAuth.tenantId },
        );
      }

      const selectClause = buildHomeBannerSelectClause(columns);
      const joinClause = buildHomeBannerJoinClause(columns);

      const [rows] = await mysqlPool.query<Array<BannerRow>>(
        `
        SELECT
          ${selectClause}
        FROM home_banners hb
        ${joinClause}
        WHERE hb.tenant_id = :tenantId
        ORDER BY hb.sort_order ASC, hb.id ASC
      `,
        { tenantId: request.adminAuth.tenantId },
      );

      const engagementByBanner = new Map<
        number,
        { impressions: number; clicks: number }
      >();
      if (await hasBannerEngagementsTable()) {
        const [engagementRows] = await mysqlPool.query<
          Array<
            RowDataPacket & {
              banner_id: number;
              impressions: number;
              clicks: number;
            }
          >
        >(
          `SELECT banner_id,
                SUM(event_type = 'impression') AS impressions,
                SUM(event_type = 'click') AS clicks
         FROM home_banner_engagements
         WHERE tenant_id = :tenantId
         GROUP BY banner_id`,
          { tenantId: request.adminAuth.tenantId },
        );
        for (const row of engagementRows) {
          engagementByBanner.set(Number(row.banner_id), {
            impressions: Number(row.impressions ?? 0),
            clicks: Number(row.clicks ?? 0),
          });
        }
      }

      const banners = rows
        .map((row) => ({
          id: row.id,
          code: row.code,
          title: row.title,
          subtitle: row.subtitle,
          imageSource: row.image_source,
          mediaType: row.media_type,
          animationDurationMs: row.animation_duration_ms,
          bannerType: row.banner_type,
          partnerName: row.partner_name || "",
          sponsoredLabel: row.sponsored_label === 1,
          ctaLabel: row.cta_label || "",
          actionType: row.action_type,
          actionValue: row.action_value || "",
          impressions: engagementByBanner.get(row.id)?.impressions ?? 0,
          clicks: engagementByBanner.get(row.id)?.clicks ?? 0,
          destinationType: row.destination_type,
          secondaryDestinationType: row.secondary_destination_type,
          targetValue: row.target_value || "",
          targetLabel:
            row.banner_type === "new_item"
              ? row.menu_item_name || row.target_value || ""
              : row.banner_type === "voucher"
                ? row.voucher_name || row.target_value || ""
                : row.target_value || "",
          startsAt: row.starts_at
            ? new Date(row.starts_at).toISOString()
            : null,
          endsAt: row.ends_at ? new Date(row.ends_at).toISOString() : null,
          scheduleLabel:
            ["event", "partner"].includes(row.banner_type) &&
            (row.starts_at || row.ends_at)
              ? `${formatDateTimeLabel(row.starts_at)}${row.starts_at && row.ends_at ? " - " : ""}${formatDateTimeLabel(row.ends_at)}`
              : "",
          placement: row.placement,
          sortOrder: row.sort_order,
          homeSortOrder: row.home_sort_order,
          floatingSortOrder: row.floating_sort_order,
          partnershipSortOrder: row.partnership_sort_order,
          floatingPriority: row.floating_priority === 1,
          status: formatBannerStatus(row),
          isActive: row.is_active === 1,
          destinationLabel: formatDestinationLabel(row.destination_type),
          secondaryDestinationLabel: row.secondary_destination_type
            ? formatDestinationLabel(row.secondary_destination_type)
            : "",
          createdAt: row.created_at
            ? new Date(row.created_at).toISOString()
            : null,
          updatedAt: row.updated_at
            ? new Date(row.updated_at).toISOString()
            : null,
        }))
        .filter((banner) => {
          const matchesSearch =
            !searchTerm ||
            String(banner.code ?? "")
              .toLowerCase()
              .includes(searchTerm) ||
            String(banner.title ?? "")
              .toLowerCase()
              .includes(searchTerm) ||
            String(banner.subtitle ?? "")
              .toLowerCase()
              .includes(searchTerm) ||
            String(banner.targetValue ?? "")
              .toLowerCase()
              .includes(searchTerm) ||
            String(banner.targetLabel ?? "")
              .toLowerCase()
              .includes(searchTerm);
          const matchesType =
            !bannerType ||
            String(banner.bannerType ?? "").toLowerCase() === bannerType;
          const matchesPlacement =
            !placement ||
            String(banner.placement ?? "").toLowerCase() === placement;
          const matchesActive =
            !isActive ||
            (isActive === "1" && banner.isActive) ||
            (isActive === "0" && !banner.isActive);
          return (
            matchesSearch && matchesType && matchesPlacement && matchesActive
          );
        });

      return { banners };
    },
  );

  app.post(
    "/v1/admin/marketing/banners",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);
      const payload = bannerCreateSchema.parse(request.body);
      const normalized = normalizeRequestBody(payload);
      validatePartnerAction(normalized);
      const columns = await getHomeBannerColumns();
      const supportsTargeting = supportsHomeBannerTargeting(columns);
      const supportsMedia = supportsHomeBannerMedia(columns);
      const selectClause = buildHomeBannerSelectClause(columns);
      const joinClause = buildHomeBannerJoinClause(columns);

      if (
        !supportsTargeting &&
        (payload.bannerType !== "general" ||
          payload.destinationType === "calendar")
      ) {
        throw new ApiError(
          412,
          "poster_targeting_unavailable",
          "Poster targeting fields are not installed in the database yet.",
        );
      }
      if (
        payload.bannerType === "partner" &&
        !supportsPartnerCampaignFields(columns)
      ) {
        throw new ApiError(
          412,
          "partner_campaign_unavailable",
          "Run the latest database migration before creating Partnership campaigns.",
        );
      }

      if (
        payload.floatingPriority === true &&
        !supportsHomeBannerFloatingPriority(columns)
      ) {
        throw new ApiError(
          412,
          "poster_priority_unavailable",
          "Poster priority is not installed in the database yet.",
        );
      }
      if (
        !supportsMedia &&
        (payload.mediaType === "gif" || payload.animationDurationMs > 0)
      ) {
        throw new ApiError(
          412,
          "poster_media_unavailable",
          "GIF poster support is not installed in the database yet.",
        );
      }

      if (
        (payload.bannerType === "voucher" ||
          payload.bannerType === "new_item") &&
        !normalized.targetValue
      ) {
        throw new ApiError(
          400,
          "missing_target",
          "Target value is required for this poster type.",
        );
      }

      if (
        (payload.bannerType === "event" ||
          payload.destinationType === "calendar") &&
        (!normalized.startsAt || !normalized.endsAt)
      ) {
        throw new ApiError(
          400,
          "missing_schedule",
          "Event posters require a start and end date.",
        );
      }

      if (
        normalized.startsAt &&
        normalized.endsAt &&
        new Date(normalized.endsAt).getTime() <=
          new Date(normalized.startsAt).getTime()
      ) {
        throw new ApiError(
          400,
          "invalid_schedule",
          "Event end time must be after the start time.",
        );
      }

      const code = buildBannerCode(payload.title);
      const sortOrder =
        normalized.sortOrder ??
        (await getNextHomeBannerSortOrder(request.adminAuth.tenantId));

      const insertParts = buildHomeBannerInsertParts(columns);
      const [result] = await mysqlPool.execute<ResultSetHeader>(
        `
        INSERT INTO home_banners (
          ${insertParts.columns.join(", ")}
        )
        VALUES (
          ${insertParts.values.join(", ")}
        )
      `,
        {
          code,
          tenantId: request.adminAuth.tenantId,
          title: payload.title,
          subtitle: payload.subtitle,
          imageSource: payload.imageSource,
          mediaType: payload.mediaType,
          animationDurationMs:
            payload.mediaType === "gif" ? payload.animationDurationMs : 0,
          bannerType: normalized.bannerType,
          partnerName: normalized.partnerName,
          sponsoredLabel: normalized.sponsoredLabel ? 1 : 0,
          ctaLabel: normalized.ctaLabel,
          actionType: normalized.actionType,
          actionValue: normalized.actionValue,
          destinationType: normalized.destinationType,
          secondaryDestinationType: normalized.secondaryDestinationType,
          targetValue: normalized.targetValue,
          startsAt: normalized.startsAt,
          endsAt: normalized.endsAt,
          placement: normalized.placement,
          sortOrder,
          homeSortOrder:
            normalized.bannerType === "partner"
              ? 0
              : sortOrder,
          floatingSortOrder: normalized.floatingPriority ? sortOrder : 0,
          partnershipSortOrder:
            normalized.bannerType === "partner"
              ? sortOrder
              : 0,
          floatingPriority: normalized.floatingPriority ? 1 : 0,
          isActive: normalized.isActive ? 1 : 0,
        },
      );

      const [rows] = await mysqlPool.query<Array<BannerRow>>(
        `
        SELECT
          ${selectClause}
        FROM home_banners hb
        ${joinClause}
        WHERE hb.id = :id AND hb.tenant_id = :tenantId
        LIMIT 1
      `,
        { id: result.insertId, tenantId: request.adminAuth.tenantId },
      );

      const created = rows[0];
      if (!created) {
        throw new ApiError(
          500,
          "banner_create_failed",
          "Banner was created but could not be loaded.",
        );
      }

      const notification = isBannerNotifiable(created)
        ? await notifyCustomersAboutPoster({
            banner: created,
            tenantId: request.adminAuth.tenantId,
            log: request.log,
          })
        : null;

      return {
        banner: {
          id: created.id,
          code: created.code,
          title: created.title,
          subtitle: created.subtitle,
          imageSource: created.image_source,
          mediaType: created.media_type,
          animationDurationMs: created.animation_duration_ms,
          bannerType: created.banner_type,
          partnerName: created.partner_name,
          sponsoredLabel: created.sponsored_label === 1,
          ctaLabel: created.cta_label,
          actionType: created.action_type,
          actionValue: created.action_value,
          destinationType: created.destination_type,
          secondaryDestinationType: created.secondary_destination_type,
          targetValue: created.target_value || "",
          targetLabel:
            created.banner_type === "new_item"
              ? created.menu_item_name || created.target_value || ""
              : created.banner_type === "voucher"
                ? created.voucher_name || created.target_value || ""
                : created.target_value || "",
          startsAt: created.starts_at
            ? new Date(created.starts_at).toISOString()
            : null,
          endsAt: created.ends_at
            ? new Date(created.ends_at).toISOString()
            : null,
          placement: created.placement,
          sortOrder: created.sort_order,
          homeSortOrder: created.home_sort_order,
          floatingSortOrder: created.floating_sort_order,
          partnershipSortOrder: created.partnership_sort_order,
          floatingPriority: created.floating_priority === 1,
          status: formatBannerStatus(created),
          isActive: created.is_active === 1,
          destinationLabel: formatDestinationLabel(created.destination_type),
          secondaryDestinationLabel: created.secondary_destination_type
            ? formatDestinationLabel(created.secondary_destination_type)
            : "",
          createdAt: created.created_at
            ? new Date(created.created_at).toISOString()
            : null,
          updatedAt: created.updated_at
            ? new Date(created.updated_at).toISOString()
            : null,
        },
        notification,
      };
    },
  );

  app.post(
    "/v1/admin/marketing/banners/reorder",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);
      const payload = bannerReorderSchema.parse(request.body);
      const bannerIds = [...new Set(payload.bannerIds)];

      if (bannerIds.length !== payload.bannerIds.length) {
        throw new ApiError(400, "duplicate_banner_ids", "Each poster may appear only once in the new order.");
      }

      const [rows] = await mysqlPool.query<Array<RowDataPacket & { id: number }>>(
        `SELECT id FROM home_banners WHERE tenant_id = :tenantId`,
        { tenantId: request.adminAuth.tenantId },
      );
      const tenantBannerIds = new Set(rows.map((row) => Number(row.id)));
      if (bannerIds.some((id) => !tenantBannerIds.has(id)) || bannerIds.length !== tenantBannerIds.size) {
        throw new ApiError(400, "invalid_banner_order", "Refresh the poster list and try ordering again.");
      }

      const connection = await mysqlPool.getConnection();
      try {
        await connection.beginTransaction();
        for (const [index, bannerId] of bannerIds.entries()) {
          await connection.execute(
            `UPDATE home_banners
             SET sort_order = :sortOrder, updated_at = UTC_TIMESTAMP()
             WHERE id = :bannerId AND tenant_id = :tenantId`,
            {
              sortOrder: (index + 1) * 10,
              bannerId,
              tenantId: request.adminAuth.tenantId,
            },
          );
        }
        await connection.commit();
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }

      return { success: true };
    },
  );

  app.post(
    "/v1/admin/marketing/banners/reorder-surface",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);
      const payload = bannerSurfaceReorderSchema.parse(request.body);
      const columns = await getHomeBannerColumns();
      if (!supportsHomeBannerSurfaceOrders(columns)) {
        throw new ApiError(
          412,
          "poster_surface_order_unavailable",
          "Run the latest database migration before arranging poster displays.",
        );
      }

      const orderColumn = {
        home: "home_sort_order",
        floating: "floating_sort_order",
        partnership: "partnership_sort_order",
      }[payload.surface];
      const filter = {
        home: "banner_type <> 'partner' AND placement IN ('home', 'both')",
        floating: "floating_priority = 1",
        partnership: "banner_type = 'partner'",
      }[payload.surface];
      const bannerIds = [...new Set(payload.bannerIds)];
      if (bannerIds.length !== payload.bannerIds.length) {
        throw new ApiError(400, "duplicate_banner_ids", "Each poster may appear only once in the new order.");
      }

      const [rows] = await mysqlPool.query<Array<RowDataPacket & { id: number }>>(
        `SELECT id FROM home_banners WHERE tenant_id = :tenantId AND ${filter}`,
        { tenantId: request.adminAuth.tenantId },
      );
      const expectedIds = new Set(rows.map((row) => Number(row.id)));
      if (
        bannerIds.length !== expectedIds.size ||
        bannerIds.some((id) => !expectedIds.has(id))
      ) {
        throw new ApiError(
          400,
          "invalid_banner_surface_order",
          "Refresh the poster list and try arranging this display again.",
        );
      }

      const connection = await mysqlPool.getConnection();
      try {
        await connection.beginTransaction();
        for (const [index, bannerId] of bannerIds.entries()) {
          await connection.execute(
            `UPDATE home_banners
             SET ${orderColumn} = :sortOrder, updated_at = UTC_TIMESTAMP()
             WHERE id = :bannerId AND tenant_id = :tenantId`,
            {
              sortOrder: (index + 1) * 10,
              bannerId,
              tenantId: request.adminAuth.tenantId,
            },
          );
        }
        await connection.commit();
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }

      return { success: true, surface: payload.surface };
    },
  );

  app.post(
    "/v1/admin/marketing/banners/:id/notify",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);
      const bannerId = z.coerce
        .number()
        .int()
        .positive()
        .parse((request.params as { id: string }).id);
      const columns = await getHomeBannerColumns();
      const selectClause = buildHomeBannerSelectClause(columns);
      const joinClause = buildHomeBannerJoinClause(columns);
      const [rows] = await mysqlPool.query<Array<BannerRow>>(
        `
        SELECT ${selectClause}
        FROM home_banners hb
        ${joinClause}
        WHERE hb.id = :bannerId AND hb.tenant_id = :tenantId
        LIMIT 1
      `,
        { bannerId, tenantId: request.adminAuth.tenantId },
      );
      const banner = rows[0];
      if (!banner)
        throw new ApiError(404, "banner_not_found", "Poster was not found.");
      if (!isBannerNotifiable(banner)) {
        throw new ApiError(
          409,
          "poster_not_live",
          "Only active, live posters can be sent to customers.",
        );
      }

      const notification = await notifyCustomersAboutPoster({
        banner,
        tenantId: request.adminAuth.tenantId,
        log: request.log,
      });
      return { success: true, notification };
    },
  );

  app.patch(
    "/v1/admin/marketing/banners/:id",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);
      const bannerId = z.coerce
        .number()
        .int()
        .positive()
        .parse((request.params as { id: string }).id);
      const payload = bannerUpdateSchema.parse(request.body);
      const normalized = normalizeRequestBody(payload);
      validatePartnerAction(normalized);
      const columns = await getHomeBannerColumns();
      const supportsTargeting = supportsHomeBannerTargeting(columns);
      const supportsMedia = supportsHomeBannerMedia(columns);

      if (
        payload.bannerType === "partner" &&
        !supportsPartnerCampaignFields(columns)
      ) {
        throw new ApiError(
          412,
          "partner_campaign_unavailable",
          "Run the latest database migration before editing Partnership campaigns.",
        );
      }

      if (
        !supportsTargeting &&
        ((payload.bannerType !== undefined &&
          payload.bannerType !== "general") ||
          payload.destinationType === "calendar")
      ) {
        throw new ApiError(
          412,
          "poster_targeting_unavailable",
          "Poster targeting fields are not installed in the database yet.",
        );
      }

      if (
        payload.floatingPriority === true &&
        !supportsHomeBannerFloatingPriority(columns)
      ) {
        throw new ApiError(
          412,
          "poster_priority_unavailable",
          "Poster priority is not installed in the database yet.",
        );
      }
      if (
        !supportsMedia &&
        (payload.mediaType === "gif" ||
          payload.animationDurationMs !== undefined)
      ) {
        throw new ApiError(
          412,
          "poster_media_unavailable",
          "GIF poster support is not installed in the database yet.",
        );
      }

      const [existingRows] = await mysqlPool.query<
        Array<RowDataPacket & { id: number; banner_type: string }>
      >(
        `
        SELECT id, banner_type
        FROM home_banners
        WHERE id = :bannerId AND tenant_id = :tenantId
        LIMIT 1
      `,
        { bannerId, tenantId: request.adminAuth.tenantId },
      );
      if (!existingRows[0]) {
        throw new ApiError(404, "banner_not_found", "Poster was not found.");
      }

      const updateFields: string[] = [];
      const params: Record<string, unknown> = {
        bannerId,
        tenantId: request.adminAuth.tenantId,
      };

      if (payload.title !== undefined) {
        updateFields.push("title = :title");
        params.title = payload.title;
      }
      if (payload.subtitle !== undefined) {
        updateFields.push("subtitle = :subtitle");
        params.subtitle = payload.subtitle;
      }
      if (payload.imageSource !== undefined) {
        updateFields.push("image_source = :imageSource");
        params.imageSource = payload.imageSource;
      }
      if (payload.mediaType !== undefined && supportsMedia) {
        updateFields.push("media_type = :mediaType");
        params.mediaType = payload.mediaType;
      }
      if (payload.animationDurationMs !== undefined && supportsMedia) {
        updateFields.push("animation_duration_ms = :animationDurationMs");
        params.animationDurationMs =
          payload.mediaType === "image" ? 0 : payload.animationDurationMs;
      }
      if (
        payload.bannerType !== undefined ||
        payload.destinationType === "calendar"
      ) {
        if (supportsTargeting) {
          updateFields.push("banner_type = :bannerType");
        }
        params.bannerType = normalized.bannerType;
      }
      if (supportsPartnerCampaignFields(columns)) {
        if (
          payload.partnerName !== undefined ||
          payload.bannerType !== undefined
        ) {
          updateFields.push("partner_name = :partnerName");
          params.partnerName = normalized.partnerName;
        }
        if (
          payload.sponsoredLabel !== undefined ||
          payload.bannerType !== undefined
        ) {
          updateFields.push("sponsored_label = :sponsoredLabel");
          params.sponsoredLabel = normalized.sponsoredLabel ? 1 : 0;
        }
        if (
          payload.ctaLabel !== undefined ||
          payload.bannerType !== undefined ||
          payload.actionType !== undefined
        ) {
          updateFields.push("cta_label = :ctaLabel");
          params.ctaLabel = normalized.ctaLabel;
        }
        if (
          payload.actionType !== undefined ||
          payload.bannerType !== undefined
        ) {
          updateFields.push("action_type = :actionType");
          params.actionType = normalized.actionType;
        }
        if (
          payload.actionValue !== undefined ||
          payload.bannerType !== undefined ||
          payload.actionType !== undefined
        ) {
          updateFields.push("action_value = :actionValue");
          params.actionValue = normalized.actionValue;
        }
      }
      if (
        payload.destinationType !== undefined ||
        payload.bannerType !== undefined
      ) {
        if (supportsTargeting) {
          updateFields.push("destination_type = :destinationType");
        }
        params.destinationType = normalized.destinationType;
      }
      if (
        payload.secondaryDestinationType !== undefined ||
        payload.bannerType !== undefined
      ) {
        if (supportsTargeting) {
          updateFields.push(
            "secondary_destination_type = :secondaryDestinationType",
          );
        }
        params.secondaryDestinationType = normalized.secondaryDestinationType;
      }
      if (
        payload.targetValue !== undefined ||
        payload.bannerType !== undefined ||
        payload.destinationType === "calendar"
      ) {
        if (supportsTargeting) {
          updateFields.push("target_value = :targetValue");
        }
        params.targetValue = normalized.targetValue;
      }
      if (
        payload.startsAt !== undefined ||
        payload.bannerType !== undefined ||
        payload.destinationType === "calendar"
      ) {
        if (supportsTargeting) {
          updateFields.push("starts_at = :startsAt");
        }
        params.startsAt = normalized.startsAt;
      }
      if (
        payload.endsAt !== undefined ||
        payload.bannerType !== undefined ||
        payload.destinationType === "calendar"
      ) {
        if (supportsTargeting) {
          updateFields.push("ends_at = :endsAt");
        }
        params.endsAt = normalized.endsAt;
      }
      if (payload.placement !== undefined) {
        updateFields.push("placement = :placement");
        params.placement = normalized.placement;
      }
      if (payload.sortOrder !== undefined) {
        updateFields.push("sort_order = :sortOrder");
        params.sortOrder = normalized.sortOrder;
      }
      if (payload.isActive !== undefined) {
        updateFields.push("is_active = :isActive");
        params.isActive = normalized.isActive ? 1 : 0;
      }
      if (payload.floatingPriority !== undefined) {
        if (supportsHomeBannerFloatingPriority(columns)) {
          updateFields.push("floating_priority = :floatingPriority");
        }
        params.floatingPriority = payload.floatingPriority ? 1 : 0;
      }

      if (updateFields.length === 0) {
        return { bannerId };
      }

      updateFields.push("updated_at = UTC_TIMESTAMP()");

      await mysqlPool.execute(
        `
        UPDATE home_banners
        SET ${updateFields.join(", ")}
        WHERE id = :bannerId AND tenant_id = :tenantId
      `,
        params as any,
      );

      return { bannerId };
    },
  );

  app.delete(
    "/v1/admin/marketing/banners/:id",
    { preHandler: authenticateAdminRequest },
    async (request) => {
      requireMarketingAccess(request);
      const bannerId = z.coerce
        .number()
        .int()
        .positive()
        .parse((request.params as { id: string }).id);

      const [result] = await mysqlPool.execute<ResultSetHeader>(
        `
        DELETE FROM home_banners
        WHERE id = :bannerId AND tenant_id = :tenantId
      `,
        { bannerId, tenantId: request.adminAuth.tenantId },
      );

      if (result.affectedRows === 0) {
        throw new ApiError(404, "banner_not_found", "Poster was not found.");
      }

      return { ok: true };
    },
  );
}
